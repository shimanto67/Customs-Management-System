<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Money Receipt - Custom Management System</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .main-content {
            max-width: 600px;
            margin: 30px auto;
            padding: 15px;
            background: #fffAAA;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
            text-align: left;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        table {
            width: 70%;
            margin: 0 auto;
            border-collapse: collapse;
            font-size: 18px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: black;
        }
        .print-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 1em;
            margin-top: 20px;
        }
        .print-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
    </div>
    <div class="main-content">
        <h2>Payment Receipt</h2>
        <p style="font-size: 20px;">Transaction ID: <?php echo uniqid(); ?></p>
        <p style="font-size: 20px;">Date: <?php echo date('Y-m-d H:i:s'); ?></p>
        <?php
        if (isset($_GET['product_id']) && isset($_GET['tax']) && isset($_GET['payment_method'])) {
            $product_id = $_GET['product_id'];
            $tax = $_GET['tax'];
            $payment_method = $_GET['payment_method'];

            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "db_cms";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch product details
            $sql = "SELECT * FROM products WHERE id = $product_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $total = $row["price"] * $row["quantity"];

                // Insert payment record
                $sql = "INSERT INTO payments (product_id, tax, payment_method) VALUES ($product_id, $tax, '$payment_method')";
                if ($conn->query($sql) === TRUE) {
                    echo "<table>";
                    echo "<tr><th>Product ID</th><td>{$row['id']}</td></tr>";
                    echo "<tr><th>Item Name</th><td>{$row['name']}</td></tr>";
                    echo "<tr><th>Description</th><td>{$row['description']}</td></tr>";
                    echo "<tr><th>Category</th><td>{$row['category']}</td></tr>";
                    echo "<tr><th>Supplier</th><td>{$row['supplier']}</td></tr>";
                    echo "<tr><th>Price</th><td>{$row['price']}</td></tr>";
                    echo "<tr><th>Quantity</th><td>{$row['quantity']}</td></tr>";
                    echo "<tr><th>Total</th><td>{$total}</td></tr>";
                    echo "<tr><th>Tax</th><td>{$tax}</td></tr>";
                    echo "<tr><th>Payment Method</th><td>" . ucfirst($payment_method) . "</td></tr>";
                    echo "</table>";
                } else {
                    echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
                }
            } else {
                echo "<p>Product not found.</p>";
            }

            $conn->close();
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
        <button class="print-btn" onclick="window.print()">Print Receipt</button>
    </div>
</body>
</html>
