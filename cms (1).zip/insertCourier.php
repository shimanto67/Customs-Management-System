<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_cms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $courier_name = $_POST['courier_name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "INSERT INTO couriers (courier_name, contact, email, address) 
            VALUES ('$courier_name', '$contact', '$email', '$address')";

    if (mysqli_query($conn, $sql)) {
        echo "New courier added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Courier</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('p.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .nav {
            margin-top: 10px;
        }
        .header a {
            color: #000000; /* Black font color */
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 1.1em;
            margin: 0 10px;
            display: inline-block;
        }
        .header a:hover {
            background-color: rgba(87, 87, 87, 0.8);
        }
        .main-content {
            max-width: 600px;
            margin: 30px auto;
            padding: 15px;
            background: #fffAAA;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input[type="text"], input[type="email"], input[type="number"], select {
            width: 90%;
            padding: 8px;
            border: none;
            border-radius: 5px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            font-size: 1em;
            color: #000000; /* Black font color */
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .footer {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
        <div class="nav">
            <a href="home.html">Home</a>
            <a href="insert.php">Insert</a>
            <a href="view.php">View</a>
            <a href="search.php">Search</a>
            <a href="report.php">Report</a>
        </div>
    </div>
    <div class="main-content">
        <h2>Insert Courier</h2>
        <form action="insertCourier.php" method="POST">
            <input type="text" id="courier_name" name="courier_name" placeholder="Courier Name" required>
            <input type="text" id="contact" name="contact" placeholder="Contact" required>
            <input type="email" id="email" name="email" placeholder="Email" required>
            <input type="text" id="address" name="address" placeholder="Address" required>
            <input type="submit" value="Insert Courier">
        </form>
    </div>
    <div class="footer">
        <p>Created by Shahwar Nadim Shimanto. ID: 23103407.</p>
    </div>
</body>
</html>
