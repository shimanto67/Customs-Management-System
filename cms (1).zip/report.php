<?php
// Database connection
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "db_cms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT 
            payments.payment_id, 
            payments.product_id, 
            payments.tax, 
            payments.payment_method, 
            payments.payment_date,
            products.name, 
            products.description, 
            products.category, 
            products.price, 
            products.quantity
        FROM 
            payments
        INNER JOIN 
            products ON payments.product_id = products.id";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report - Custom Management System</title>
    <script>
        function printReport() {
            window.print();
        }
    </script>

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('p.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .nav {
            margin-top: 10px;
        }
        .header a {
            color: #000000; /* Black font color */
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 1.1em;
            margin: 0 10px;
            display: inline-block;
        }
        .header a:hover {
            background-color: rgba(87, 87, 87, 0.8);
        }
        .main-content {
            max-width: 1000px;
            margin: 60px auto;
            padding: 40px;
            background: #fffAAA; /* White background */
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
            flex: 1;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            color: #000000; /* Black font color */
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #FFD700;
            color: black;
        }
        .footer {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 15px;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
        .print-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none; /* Ensure it looks like a button */
        }
        .print-btn:hover {
            background-color: #45a049;
        }
    </style>

</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
        <div class="nav">
            <a href="home.html">Home</a>
            <a href="insert.php">Insert</a>
            <a href="view.php">View</a>
            <a href="search.php">Search</a>
            <a href="report.php">Report</a>
        </div>
    </div>
    <div class="main-content">
        <h2>Report</h2>
        <button class="print-btn" onclick="printReport()">Print Report</button>
        <?php
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Payment ID</th><th>Product ID</th><th>Tax</th><th>Payment Method</th><th>Payment Date</th>
                  <th>Product Name</th><th>Description</th><th>Category</th><th>Price</th><th>Quantity</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['payment_id']}</td><td>{$row['product_id']}</td><td>{$row['tax']}</td>
                      <td>{$row['payment_method']}</td><td>{$row['payment_date']}</td><td>{$row['name']}</td>
                      <td>{$row['description']}</td><td>{$row['category']}</td><td>{$row['price']}</td>
                      <td>{$row['quantity']}</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No records found.</p>";
        }

        $conn->close();
        ?>
    </div>
    <div class="footer">
        <p>Created by Shahwar Nadim Shimanto. ID: 23103407.</p>
    </div>
</body>
</html>
