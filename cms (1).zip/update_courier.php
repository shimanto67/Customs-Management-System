<?php
// Database connection
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "db_cms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM couriers WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No record found.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $courier_name = $_POST["courier_name"];
    $contact = $_POST["contact"];
    $email = $_POST["email"];
    $address = $_POST["address"];

    $sql = "UPDATE couriers SET courier_name='$courier_name', contact='$contact', email='$email', address='$address' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully!";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Courier - Custom Management System</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('p.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .nav {
            margin-top: 10px;
        }
        .header a {
            color: #000000; /* Black font color */
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 1.1em;
            margin: 0 10px;
            display: inline-block;
        }
        .header a:hover {
            background-color: rgba(87, 87, 87, 0.8);
        }
        .main-content {
            max-width: 600px;
            margin: 30px auto;
            padding: 15px;
            background: #fffAAA;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input[type="text"], input[type="email"], input[type="number"], select {
            width: 90%;
            padding: 8px;
            border: none;
            border-radius: 5px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            font-size: 1em;
            color: #000000; /* Black font color */
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .footer {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
        <div class="nav">
            <a href="home.html">Home</a>
            <a href="insert.php">Insert</a>
            <a href="view.php">View</a> 
            <a href="search.php">Search</a>
            <a href="report.php">Report</a>
        </div>
    </div>
    <div class="main-content">
        <h2>Edit Courier</h2>
        <form action="update_courier.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <input type="text" id="courier_name" name="courier_name" value="<?php echo $row['courier_name']; ?>" required>
            <input type="text" id="contact" name="contact" value="<?php echo $row['contact']; ?>" required>
            <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" required>
            <input type="text" id="address" name="address" value="<?php echo $row['address']; ?>" required>
            <input type="submit" value="Update Courier">
        </form>
    </div>
    <div class="footer">
        <p>Created by Shahwar Nadim Shimanto. ID: 23103407.</p>
    </div>
</body>
</html>
