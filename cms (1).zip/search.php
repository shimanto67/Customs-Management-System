<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_cms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Products - Custom Management System</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('p.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .nav {
            margin-top: 10px;
        }
        .header a {
            color: #000000; /* Black font color */
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 1.1em;
            margin: 0 10px;
            display: inline-block;
        }
        .header a:hover {
            background-color: rgba(87, 87, 87, 0.8);
        }
        .main-content {
            max-width: 1000px;
            margin: 60px auto;
            padding: 40px;
            background: #fffAAA; /* White background */
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
            flex: 1;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            color: #000000; /* Black font color */
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #FFD700;
            color: black;
        }
        .footer {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 15px;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
        .pay-tax-btn {
            background-color: #4CAF50;
            color: white;
            padding: 3px 8px; /* Smaller padding */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none; /* Ensure it looks like a button */
        }
        .pay-tax-btn:hover {
            background-color: #45a049;
        }
        .search-bar {
            margin-bottom: 20px;
        }
        .search-bar input {
            padding: 10px;
            font-size: 1em;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 300px;
            margin-right: 10px;
        }
        .search-bar button {
            padding: 10px 15px;
            font-size: 1em;
            border-radius: 5px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        .search-bar button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
        <div class="nav">
            <a href="home.html">Home</a>
            <a href="insert.php">Insert</a>
            <a href="view.php">View</a>
            <a href="search.php">Search</a>
            <a href="report.php">Report</a>
        </div>
    </div>
    <div class="main-content">
        <h2>Search Products</h2>
        <div class="search-bar">
            <form action="search.php" method="GET">
                <input type="text" name="query" placeholder="Search by ID">
                <button type="submit">Search</button>
            </form>
        </div>
        <?php
        if (isset($_GET['query'])) {
            $search_query = $_GET['query'];

            // Fetch products based on search query
            $sql = "SELECT * FROM products WHERE id = '$search_query'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>Product ID</th><th>Item Name</th><th>Description</th><th>Category</th><th>Courier ID</th><th>Price</th><th>Quantity</th><th>Total</th><th>Tax</th><th>Action</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    $total = $row["price"] * $row["quantity"];
                    $tax = $total * 0.10; // Assuming a 10% tax rate
                    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['description']}</td><td>{$row['category']}</td><td>{$row['price']}</td><td>{$row['quantity']}</td><td>{$total}</td><td>{$tax}</td><td><a href='pay_tax.php?id={$row['id']}&tax={$tax}' class='pay-tax-btn'>Pay Tax</a></td></tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No products found.</p>";
            }

            $conn->close();
        } else {
            echo "<p>Please enter a search query.</p>";
        }
        ?>
    </div>
    <div class="footer">
        <p>Created by Shahwar Nadim Shimanto. ID: 23103407.</p>
    </div>
</body>
</html>
