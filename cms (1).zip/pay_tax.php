<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Tax - Custom Management System</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('p.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #000000; /* Black font color */
            text-align: center;
        }
        .header {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        .header h1 {
            margin: 0;
            font-size: 3em;
        }
        .nav {
            margin-top: 10px;
        }
        .header a {
            color: #000000; /* Black font color */
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 1.1em;
            margin: 0 10px;
            display: inline-block;
        }
        .header a:hover {
            background-color: rgba(87, 87, 87, 0.8);
        }
        .main-content {
            max-width: 600px;
            margin: 30px auto;
            padding: 15px;
            background: #fffAAA;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            color: #000000; /* Black font color */
        }
        h2 {
            margin-bottom: 20px;
            font-size: 2em;
            color: #000000; /* Black font color */
        }
        .highlight {
            color: red;
            font-weight: bold;
        }
        .submit-btn {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .footer {
            background-color: #fffAAA; /* Solid color that matches the bg image */
            color: #000000; /* Black font color */
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Custom Management System</h1>
        <div class="nav">
            <a href="home.html">Home</a>
            <a href="insert.php">Insert</a>
            <a href="view.php">View</a>
            <a href="search.php">Search</a>
            <a href="report.php">Report</a>
        </div>
    </div>
    <div class="main-content">
        <h2>Pay Tax</h2>
        <?php
        if (isset($_GET['id']) && isset($_GET['tax'])) {
            $product_id = $_GET['id'];
            $tax = $_GET['tax'];
        ?>
        <p>The total tax for this product is <span class="highlight"><?php echo number_format($tax, 2); ?></span></p>
        <form action="money_receipt.php" method="GET">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" name="tax" value="<?php echo $tax; ?>">
            <input type="hidden" name="payment_method" value="N/A">
            <button type="submit" class="submit-btn">Pay Now</button>
        </form>
        <?php
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
    </div>
    <div class="footer">
        <p>Created by Shahwar Nadim Shimanto. ID: 23103407.</p>
    </div>
</body>
</html>
